﻿using System;

namespace GClientes.Domain.Entities
{
    public abstract class EntityBase
    {

        public DateTime DtInclusao { get; set; }
       // public string UsuarioInclusao { get; set; }

       // public DateTime? DtAlteracao { get; set; }
       // public string UsuarioAlteracao { get; set; }
        

    }
}
