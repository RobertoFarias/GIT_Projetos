﻿using GClientes.Domain.Entities;
using System.Collections.Generic;

namespace GClientes.Domain.Interfaces.Services
{
    public interface IClienteService: IServiceBase<Cliente>
    {
        
       
    }
}
