﻿using GClientes.Domain.Entities;

namespace GClientes.Domain.Interfaces.Services
{
    public interface ISaldoService : IServiceBase<Saldo>
    {

    }

}
