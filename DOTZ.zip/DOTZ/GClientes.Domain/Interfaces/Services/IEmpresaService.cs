﻿using GClientes.Domain.Entities;

namespace GClientes.Domain.Interfaces.Services
{
    public interface IEmpresaService: IServiceBase<Empresa>
    {
    }
}
