﻿using GClientes.Domain.Entities;

namespace GClientes.Domain.Interfaces.Services
{
    public interface ICategoriaService : IServiceBase<Categoria>
    {
    }
}
