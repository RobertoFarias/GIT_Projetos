﻿using GClientes.Domain.Entities;
using System.Collections.Generic;

namespace GClientes.Domain.Interfaces.Repositories
{
    public interface IClienteRepository: IRepositoryBase<Cliente>
    {

    
    }
}
