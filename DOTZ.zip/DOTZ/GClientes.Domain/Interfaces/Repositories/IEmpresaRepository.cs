﻿using GClientes.Domain.Entities;

namespace GClientes.Domain.Interfaces.Repositories
{
    public interface IEmpresaRepository: IRepositoryBase<Empresa>
    {
    }
}
