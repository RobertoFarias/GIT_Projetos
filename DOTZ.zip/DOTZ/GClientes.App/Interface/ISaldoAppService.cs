﻿using GClientes.Domain.Entities;

namespace GClientes.App.Interface
{
    public interface ISaldoAppService : IAppServiceBase<Saldo>
    {

    }
}
