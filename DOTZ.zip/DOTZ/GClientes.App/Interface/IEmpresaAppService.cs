﻿using GClientes.Domain.Entities;

namespace GClientes.App.Interface
{
    public interface IEmpresaAppService : IAppServiceBase<Empresa>
    {
    }
}
