﻿using GClientes.Domain.Entities;

namespace GClientes.App.Interface
{
    public interface ICategoriaAppService : IAppServiceBase<Categoria>
    {
    }
}
