﻿using GClientes.Domain.Entities;

namespace GClientes.App.Interface
{
    public interface IProdutoAppService : IAppServiceBase<Produto>
    {

    }
}
